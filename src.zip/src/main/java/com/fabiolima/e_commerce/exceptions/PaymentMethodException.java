package com.fabiolima.e_commerce.exceptions;

public class PaymentMethodException extends IllegalArgumentException{
    public PaymentMethodException (String message){super(message);}
}
